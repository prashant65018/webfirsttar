<?php
/**
 * @file
 * Contains \Drupal\fibonacci_list\Plugin\Block\FibonacciBlock.
 */

namespace Drupal\fibonacci_list\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Provides a 'fibonaccilist' block.
 *
 * @Block(
 *   id = "fibonaccilist_block",
 *   admin_label = @Translation("Fibonacci List block"),
 *   category = @Translation("Custom fibonaccilist block")
 * )
 */
class FibonacciBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {

    $output = array();
    $query = \Drupal::entityQuery('node')
    ->condition('status', 1)
    ->sort('created', 'DESC')
    ->range(0,5);
    $nodeIds = $query->execute();

    foreach($nodeIds as $nid) {
      $node = \Drupal\node\Entity\Node::load($nid);
      $day_of_date = date('d',$node->created->value);
      $intDay = intval($day_of_date);
      $n1 = (5 * $intDay * $intDay + 4);
      $n2 = (5 * $intDay * $intDay - 4);
      $sq1 = sqrt($n1);
      $sq2 = sqrt($n2);
      $sq1Tmp = (int) $sq1;
      $sq2Tmp = (int) $sq2;
      $subSq1 = $sq1 - $sq1Tmp;
      $subSq2 = $sq2-$sq2Tmp;
      if(!$subSq1 || !$subSq2){
        //True if fibonacci number
        $output[] = $node->title->value;
      }

    }
    $output_str = '';
    foreach($output as $outputVal) {
      $output_str = $output_str.'<li>'.$outputVal.'</li>';
    }
    $render_output = '<ul>'.$output_str.'</ul>';
    $out = [
      '#type' => 'markup',
      '#markup' => $render_output,
      '#attached' => array(
      'library' => array(
        'fibonacci_list/fibonacci_list'
      )
      )
      ];
    return $out;
    }

  /**
   * {@inheritdoc}
   */
  public function blockAccess(AccountInterface $account)
  {
    return AccessResult::allowedIfHasPermission($account, 'view fibonacci_list');
  }
}

